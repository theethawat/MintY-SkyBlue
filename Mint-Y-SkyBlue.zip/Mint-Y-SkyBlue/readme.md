# Linux Mint-Y Shy Blue Theme
Make your linux more colorful with sky blue theme that based on Linux Mint Mint-Y Theme on Linux Mint 19.0 Tessa
Editing from Linux Mint Mint-Y theme on my computer Supporting GTK3.0 GTK2.0. It only Control and Windows boarder the logo is not now.
## Screenshot
Make a Linux Mint Windows button to deepskyblue and other notify,click,progress bar too
with deepskyblue and other shade of skyblue


![Screenshot1][ReadmePhoto/Wallpaper.png]

![Screenshot2][ReadmePhoto/Screenshot2.png]

## To Downloading
